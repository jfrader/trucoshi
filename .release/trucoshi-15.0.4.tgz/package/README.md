# Trucoshi

Bitcoin Lightning server for the Argentinian card game Truco.

- [Play Trucoshi](https://trucoshi.com)
- [Web client](https://github.com/jfrader/trucoshi-client)
- [Lightning Accounts](https://github.com/jfrader/lightning-accounts)

## Setup

```sh
yarn
yarn build
yarn test
```

Node 24 and Yarn 1.22.22 are supported.

## Full development stack

Keep `trucoshi-client` beside this repository, then run:

```sh
yarn dev:all
```

Docker builds the pinned Lightning Accounts revision and starts PostgreSQL,
Bitcoin regtest, LND, Lightning Accounts, Trucoshi, and the client. A separate
Lightning Accounts checkout is not needed. The first build requires internet
access; later runs can use Docker's cache.

If Docker requires sudo, use `yarn dev:all:sudo-docker`. Do not run Yarn or the
launcher itself with sudo.

## npm package

The [`trucoshi`](https://www.npmjs.com/package/trucoshi) package provides the
shared event contract, protocol types, and card library. It includes the
TypeScript sources and build configuration for the published JavaScript.

To rebuild an unpacked package:

```sh
yarn source:install
yarn build:package-source
```

Docker server images use the pinned dependencies in `server-runtime/`. Run
`yarn runtime:verify` after changing a runtime manifest.

## Operations

Health probes are available at `GET /health/live` and `GET /health/ready`.
Admission controls are available at `GET /ops/status`, `POST /ops/drain`, and
`POST /ops/resume`.

Use different random values for `APP_OPS_STATUS_TOKEN` and `APP_OPS_TOKEN`.
The first is read-only; the second authorizes drain and resume operations.

Betting is enabled only when `APP_BETS_ENABLED=1`. Configure
`APP_MAX_BET`, `APP_RAKE_PERCENT`, and a Lightning Accounts application user
before enabling it. Lightning Accounts must have `WALLET_ENABLED=1`, and the
application email must be listed in `APPLICATION_EMAILS` with the APPLICATION
or ADMIN role.

## CLI

```sh
yarn cli:play
yarn cli:autoplay
```

## Donations

[Donate Bitcoin](https://jfrader.com/tips)

## License

Copyright (C) 2023-2026 jfrader.

Trucoshi is licensed under GPL-3.0-or-later. See [LICENSE](LICENSE).
